const mongoose = require('mongoose');

const InstructionSchema = new mongoose.Schema({
    instructions: [
        {
            key: String,
            value: String
        }
    ]
});

// Export the Instruction model
module.exports = mongoose.model('Instruction', InstructionSchema);
